package Node;
import Main.Token;
//BType → 'int'
public class BType{
    public Token type;
    public BType(Token type)
    {
        this.type = type;
    }
}
