package Node;

import Main.Token;

public class FuncType {
    Token type;
    public FuncType(Token type)
    {
        this.type = type;
    }
}
