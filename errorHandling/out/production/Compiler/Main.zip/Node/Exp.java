package Node;
//  Exp → AddExp
public class Exp {
    public AddExp addExp = null;
    public Exp(AddExp addExp)
    {
        this.addExp = addExp;
    }
}
