package Node;
//  Exp → AddExp
public class Exp {
    AddExp addExp = null;
    public Exp(AddExp addExp)
    {
        this.addExp = addExp;
    }
}
