package Node;

import Main.Token;

public class Number {
    Token intConst = null;
    public Number(Token intConst)
    {
        this.intConst = intConst;
    }
}
