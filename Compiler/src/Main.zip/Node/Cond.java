package Node;
//  Cond → LOrExp
public class Cond {
    LOrExp lOrExp;
    public Cond(LOrExp lOrExp)
    {
        this.lOrExp = lOrExp;
    }
}
